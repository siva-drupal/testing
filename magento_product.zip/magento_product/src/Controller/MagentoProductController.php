<?php

namespace Drupal\magento_product\Controller;

use Drupal\Core\Controller\ControllerBase;

/**
 * An example controller.
 */
class MagentoProductController extends ControllerBase {

  /**
   * Returns a render-able array for a test page.
   */
  public function content() {
    $user = \Drupal\user\Entity\User::load(\Drupal::currentUser()->id());
    $test = $user->field_user_token->value;
    echo $test;
    $uri = 'http://34.69.39.72/rest/b2c/V1/carts/mine/items';
    $user_token = 'Bearer ' . $test;
    $response = \Drupal::httpClient()->get($uri, array('headers' => array('Authorization' => $user_token)));
    $data = json_decode($response->getBody());
    // echo "<pre>";
    // print_r($data);
    // exit;
    $test .= '<table class = "cart-table">
      <tr>
        <th>Product Name</th>
        <th>Unit Price</th>
        <th>Quantity</th>
        <th>Sub Total</th>
      </tr>';

    foreach($data as $key => $value){
      $subtotal = $value->price * $value->qty;
      $sub_total_array[] = $subtotal;
      $test .= '
      <tr>
        <td>'.$value->name.'</td>
        <td>$ '.$value->price.'</td>
        <td>'.$value->qty.'</td>
        <td>$ '.$subtotal.'</td>
      </tr>';
    }
    $total = array_sum($sub_total_array);
    $test .= '
    <tr>
    <td></td>
    <td></td>
    <td><b>Total</b></td>
    <td><b>$ '.$total.'</b></td>
    </tr>
    </table>';
    return [
      // Your theme hook name.
      '#markup' => $test,
    ];
    echo"<pre>";
    print_r($data);
    exit;
    $url = 'http://34.69.39.72/rest/b2c/V1/carts/mine';
    $ch = curl_init($url);
    $options = array(
      CURLOPT_RETURNTRANSFER => true,
      CURLOPT_POST            => 1,            
      // CURLOPT_POSTFIELDS     => $pay_load,    
      CURLOPT_HTTPHEADER     => array(
        "Content-Type: application/json",
        "Authorization: Bearer ww9k8g59i1e7k5zrap9s0zs8idtrp0r9",
      )
    );
    curl_setopt_array($ch,$options);
    $data = curl_exec($ch);
  echo "pre";
  print_r($data);
  exit;
    // try{
        // $uri = 'https://master-7rqtwti-sz2ljpmf2drki.us-4.magentosite.cloud//rest/default/V1/carts/mine/items';
        // $response = \Drupal::httpClient()->post($uri, 
        //  array(
        //   'verify' => true,
        //   'headers' => array('Authorization' => 'Bearer imifpp6fj7rcscblipn1wo352n8tzo4k'),
        //   'form_params' => array('cartItem' => array('sku'=>'24-WG085', 'qty' => '1', 'quote_id' => '1'))
        //  )
        // );
        // $data = json_decode($response->getBody()->getContents());
        // echo "<pre>";
        // print_r($data);
        // exit;
        
        $uri = 'http://34.69.39.72/rest/b2c/V1/categories/53/products';
        $response = \Drupal::httpClient()->get($uri, array('headers' => array('Authorization' => 'Bearer er7w64tyr1abuzrxd8tidmbrv0pkdc0y')));
        $data = json_decode($response->getBody());
        foreach($data as $data_key => $data_value){
          // echo "<pre>";
          // print_r($data_value);
          $sku = $data_value->sku;
          $uri = 'http://34.69.39.72/rest/V1/products/' . $sku;
          $response = \Drupal::httpClient()->get($uri, array('headers' => array('Authorization' => 'Bearer er7w64tyr1abuzrxd8tidmbrv0pkdc0y')));
          $data2 = json_decode($response->getBody());
          echo"<pre>";
          print_r($data2);
          $product_variables[] = array(
            'sku' => $data2->sku,
            'title' => $data2->name,
            'price' => $data2->price,
            'image' => 'http://34.69.39.72/media/catalog/product/' . $data2->media_gallery_entries[0]->file,
          ); 
          // echo "<pre>";
          // print_r($data2);
          // $price = $data->price;
          // $sku = $data->sku;
          // $title = $data->name;
        }
        // echo"<pre>";
        // print_r($product_variables); 
        exit;
        // return [
        //   // Your theme hook name.
        //   '#theme' => 'magento_product',      
        //   // Your variables.
        //   '#variables' => 'ooo',
        // ];

        // $token='imifpp6fj7rcscblipn1wo352n8tzo4k';
        // $productData = [
        //     'cart_item' => [
        //         'quote_id' => 1,
        //         'sku' => '24-WG085',
        //         'qty' => 1
        //     ]
        // ];
        // $ch = curl_init("https://master-7rqtwti-sz2ljpmf2drki.us-4.magentosite.cloud//rest/default/V1/carts/mine/items");
        // curl_setopt($ch, CURLOPT_CUSTOMREQUEST, "POST");
        // curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
        // curl_setopt($ch, CURLOPT_POSTFIELDS, json_encode($productData, JSON_FORCE_OBJECT));
        // curl_setopt($ch, CURLOPT_HTTPHEADER, array("Content-Type: application/json", "Authorization: Bearer " . $token));
        
        
        // $result = curl_exec($ch);
        
        
        // $result = json_decode($result, 1);
        // echo '<pre>';print_r($result); 
        // $customer = array(
        //   "cartItem" => array(
        //     "sku" => '24-WG085',
        //     "qty" => 1,
        //     "quote_id" => 1,
        //   ),
        //   );
          
        // $post_data = json_encode($customer);
        // \Drupal::logger('magento')->notice($post_data);
       
        // $client = \Drupal::httpClient();
        // $url = 'https://master-7rqtwti-sz2ljpmf2drki.us-4.magentosite.cloud/rest/default/V1/carts/mine/items';
       
        // $headers = ['Content-Type' => 'application/json', 'Authorization' => 'Bearer imifpp6fj7rcscblipn1wo352n8tzo4k'];
        // $response = $client->request('POST', $url, $headers, $post_data);
        // $body = $response->getBody()->getContents();
        // $status = $response->getStatusCode();
        // \Drupal::logger('magento')->notice($body);
       
        // print_r($body);
        // echo '</br>';
        // print_r($status);
        // exit;       
    // }
    
    // catch(Exception $e){
      // print_r($e->getMessage());
      // exit;
    // }
    // $build = [
    //   '#markup' => $this->t('Hello World!'),
    // ];
    // return $build;
    // Do something with your variables here.
    // $myText = 'This is not just a default text!';
    // $myNumber = 1;
    // $myArray = [1, 2, 3];
    // $variables = 'testing';

    // return [
    //   // Your theme hook name.
    //   '#theme' => 'magento_product',      
    //   // Your variables.
    //   '#variable1' => $myText,
    //   '#variable2' => $myNumber,
    //   '#variable3' => $myArray,
    //   '#variables' => $variables,
    // ];

    $uri = 'https://master-7rqtwti-sz2ljpmf2drki.us-4.magentosite.cloud/rest/V1/products/24-WG085';
    $response = \Drupal::httpClient()->get($uri, array('headers' => array('Authorization' => 'Bearer imifpp6fj7rcscblipn1wo352n8tzo4k')));
    $data = json_decode($response->getBody());
    $price = $data->price;
    $sku = $data->sku;
    $title = $data->name;
    return [
      // Your theme hook name.
      '#theme' => 'magento_product',      
      // Your variables.
      '#price' => $price,
      '#sku' => $sku,
      '#title' => $title,
    ];
  }
  public function add_cart_magento() {
    
  }

}