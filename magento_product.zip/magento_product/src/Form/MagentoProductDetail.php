<?php

namespace Drupal\magento_product\Form;

use Drupal\Core\Form\FormStateInterface;

use Drupal\user\Entity\Role;

use Drupal\Core\Form\ConfigFormBase;

use Drupal\redirect\Entity\Redirect;

use Drupal\Core\Url;

/**
 * Smooth scroll.
 */
class MagentoProductDetail extends ConfigFormBase {

  /**
   * {@inheritdoc}
   */
  public function getFormId() {
    return 'magento_add_to_cart';
  }

  /**
   * {@inheritdoc}
   */
  protected function getEditableConfigNames() {
    return [
      'smooth_mouse_scrolling.settings',
    ];
  }

  /**
   * {@inheritdoc}
   */
  public function buildForm(array $form, FormStateInterface $form_state) {
    $current_uri = \Drupal::request()->getRequestUri();
    $url_explode = explode('/', $current_uri);
    $product_sku = $url_explode[2];
    $uri = 'http://34.69.39.72/rest/V1/products/'.$product_sku;
    $response = \Drupal::httpClient()->get($uri, array('headers' => array('Authorization' => 'Bearer er7w64tyr1abuzrxd8tidmbrv0pkdc0y')));
    $data = json_decode($response->getBody());
    $pro_img = 'http://34.69.39.72/media/catalog/product/'.$data->media_gallery_entries[0]->file;
    $price = $data->price;
    $sku = $data->sku;
    $title = $data->name;
    $is_anonymous = \Drupal::currentUser()->isAnonymous();
    if($is_anonymous){
      $button_link = 'Login to Continue';
    }
    else{
      $button_link = 'Add to Cart';
    }

    $form['pro_image'] = [
        '#prefix' => '<div class = "pro-left">',
        '#markup' => '<img src="' . $pro_img . '" alt="picture">',
        '#suffix' => '</div>',
    ];
    $form['pro_title'] = [
        '#prefix' => '<div class = "pro-right">',
        '#markup' => '<h1>'.$title.'</h1>',
    ];
    $form['pro_sku_hidden'] = [
      '#type' => 'hidden',
      '#default_value' => $sku,
    ];
    $form['pro_price'] = [
        '#prefix' => '<div class = "cart-sec-2">',
        '#markup' => '<p class = "pro_price">$'.$price.'</p>',
    ];
    $form['pro_sku'] = [
      '#markup' => '<p class = "pro_sku">SKU#:  '.$sku.'</p>',
      '#suffix' => '</div>',
    ];
    if(!$is_anonymous){
    $form['pro_quantity'] = array(
        '#type' => 'textfield',
        '#attributes' => array(
            ' type' => 'number', // insert space before attribute name :)
        ),
        '#title' => 'Quantity',
        '#required' => true,
        '#maxlength' => 3
    );
    }

    $form['actions']['#type'] = 'actions';
    $form['actions']['submit'] = [
      '#type' => 'submit',
      '#value' => $button_link,
      '#button_type' => 'primary',
      '#suffix' => '</div>',
    ];
    return $form;
  }

  /**
   * {@inheritdoc}
   */
  public function validateForm(array &$form, FormStateInterface $form_state) {
    // echo $form_state->getValue('submit');
    // exit;
    // if($form_state->getValue('submit') == 'Login to continue'){
    //   // Redirect::create([
    //   //   'redirect_source' => 'user/login',
    //   //   'redirect_redirect' => 'internal:/node/1',
    //   //   'language' => 'und',
    //   //   'status_code' => '301',
    //   // ])->save();
    //   $url = Url::fromRoute('/your/destination/path');
    //   $form_state->setRedirectUrl($url);
    // }
  }

  /**
   * {@inheritdoc}
   */
  public function submitForm(array &$form, FormStateInterface $form_state) {
    if($form_state->getValue('submit') == 'Login to continue'){
      $url = Url::fromUserInput('/user');
      $form_state->setRedirectUrl($url);
      return;
    }
    $current_user = \Drupal\user\Entity\User::load(\Drupal::currentUser()->id());
    $token = $current_user->field_user_token->value;
    $quote_id = $current_user->field_quote_id->value;
    
    $quantity = (int) $form_state->getValue('pro_quantity');
    $current_uri = \Drupal::request()->getRequestUri();
    $url_explode = explode('/', $current_uri);
    $product_sku = $url_explode[2];
    // $token='pyjk4l8jpf3qzm73p10j8ec6mvom9ujd';
    $productData = [
        'cart_item' => [
        'quote_id' => $quote_id,
        'sku' => $product_sku,
        'qty' => $quantity
      ]
    ];
    $ch = curl_init("http://34.69.39.72/rest/b2c/V1/carts/mine/items");
    curl_setopt($ch, CURLOPT_CUSTOMREQUEST, "POST");
    curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
    curl_setopt($ch, CURLOPT_POSTFIELDS, json_encode($productData, JSON_FORCE_OBJECT));
    curl_setopt($ch, CURLOPT_HTTPHEADER, array("Content-Type: application/json", "Authorization: Bearer " . $token));
    $result = curl_exec($ch);
    \Drupal::logger('magento')->notice("Add to cart Service Payload ----->".$result);
    if($result){
      drupal_set_message(t('The product is added into the cart'), 'status', TRUE);
    }
  }
}
