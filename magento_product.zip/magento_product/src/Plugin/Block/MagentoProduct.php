<?php

namespace Drupal\magento_product\Plugin\Block;

use Drupal\Core\Access\AccessResult;
use Drupal\Core\Block\BlockBase;
use Drupal\Core\Form\FormStateInterface;
use Drupal\Core\Session\AccountInterface;

/**
 * Provides a block with a simple text.
 *
 * @Block(
 *   id = "magento_block",
 *   admin_label = @Translation("Magento category product block"),
 * )
 */
class MagentoProduct extends BlockBase {
  /**
   * {@inheritdoc}
   */
  public function build() {
    $uri = 'http://34.69.39.72/rest/b2c/V1/categories/51/products';
    $response = \Drupal::httpClient()->get($uri, array('headers' => array('Authorization' => 'Bearer er7w64tyr1abuzrxd8tidmbrv0pkdc0y')));
    $data = json_decode($response->getBody());
    foreach($data as $data_key => $data_value){
      $sku = $data_value->sku;
      $uri = 'http://34.69.39.72/rest/V1/products/' . $sku;
      $response = \Drupal::httpClient()->get($uri, array('headers' => array('Authorization' => 'Bearer er7w64tyr1abuzrxd8tidmbrv0pkdc0y')));
      $data2 = json_decode($response->getBody());
      $pro_img = 'http://34.69.39.72/media/catalog/product/'.$data2->media_gallery_entries[0]->file;
      $cart_link = 'product-display/'.$data2->sku;
      $test .= '<div class="category-products">
        <img src ='.$pro_img.'></img>
        <h2 class = "title">'.$data2->name.'</h2>
        <p class = "price"> $'.$data2->price.'</p>
        <a href = '.$cart_link.'>View Product</a>
        </div>';
    }

    return [
      '#markup' => $test,
    ];
  }

  /**
   * {@inheritdoc}
   */
  protected function blockAccess(AccountInterface $account) {
    return AccessResult::allowedIfHasPermission($account, 'access content');
  }

  /**
   * {@inheritdoc}
   */
  public function blockForm($form, FormStateInterface $form_state) {
    $config = $this->getConfiguration();

    return $form;
  }

  /**
   * {@inheritdoc}
   */
  public function blockSubmit($form, FormStateInterface $form_state) {
    $this->configuration['magento_product_settings'] = $form_state->getValue('magento_product_settings');
  }
}