<?php

namespace Drupal\magento_product\Plugin\Block;

use Drupal\Core\Access\AccessResult;
use Drupal\Core\Block\BlockBase;
use Drupal\Core\Form\FormStateInterface;
use Drupal\Core\Session\AccountInterface;

/**
 * Provides a block with a simple text.
 *
 * @Block(
 *   id = "cart_block",
 *   admin_label = @Translation("Cart block"),
 * )
 */
class AddtoCart extends BlockBase {
  /**
   * {@inheritdoc}
   */
  public function build() {
    try{
      $user = \Drupal\user\Entity\User::load(\Drupal::currentUser()->id());
      $token = $user->field_user_token->value;

      $uri = 'http://34.69.39.72/rest/b2c/V1/carts/mine/items';
      $user_token = 'Bearer ' . $token;
      $response = \Drupal::httpClient()->get($uri, array('headers' => array('Authorization' => $user_token)));
      $data = json_decode($response->getBody());

      $cart_block .= '<table class = "cart-table">
        <tr>
          <th>Product Name</th>
          <th>Unit Price</th>
          <th>Quantity</th>
          <th>Sub Total</th>
        </tr>';

      foreach($data as $key => $value){
        $subtotal = $value->price * $value->qty;
        $sub_total_array[] = $subtotal;
        $cart_block .= '
        <tr>
          <td>'.$value->name.'</td>
          <td>$ '.$value->price.'</td>
          <td>'.$value->qty.'</td>
          <td>$ '.$subtotal.'</td>
        </tr>';
      }
      $total = array_sum($sub_total_array);
      $cart_block .= '
      <tr>
      <td></td>
      <td></td>
      <td><b>Total</b></td>
      <td><b>$ '.$total.'</b></td>
      </tr>
      </table>';

      return [
        '#markup' => $cart_block,
      ];
    }
    catch(\GuzzleHttp\Exception\RequestException $e){
      return [
        '#markup' => "<b>You don't have any items. <a href = 'products'>Continue Shopping</a><b>",
        '#cache' => [
          'max-age' => 0,
          'tags' => ['my_block_tag']
        ],
      ];
    }
  }

  /**
   * {@inheritdoc}
   */
  protected function blockAccess(AccountInterface $account) {
    return AccessResult::allowedIfHasPermission($account, 'access content');
  }

  /**
   * {@inheritdoc}
   */
  public function blockForm($form, FormStateInterface $form_state) {
    $config = $this->getConfiguration();

    return $form;
  }

  /**
   * {@inheritdoc}
   */
  public function blockSubmit($form, FormStateInterface $form_state) {
    $this->configuration['cart_block_settings'] = $form_state->getValue('cart_block_settings');
  }
}